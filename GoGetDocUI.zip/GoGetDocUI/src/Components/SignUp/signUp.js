import React from 'react';
import './signUp.css';
  
const SignUp=()=> {

    return (
        <div className="infoCard" >
            <div className="signUpCard">
                <div className="cardHeadingDiv">
                    <label className="cardHeading">Sign Up For Beta</label>
                </div>
                <input type="text" className="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" className="signUpFields"/>
                <input type="password" className="form-control" placeholder="Password" aria-label="password" aria-describedby="basic-addon1" className="signUpFields"/>
                <label className="signUpConditions">
                    By clicking 'next', you agree to GoGetDoc LLC <a href="/#/">Terms of Service</a> and acknowledge that you have read <a  href="/#/">Privacy Policy</a>. 
                    You also Consent to Receive calls and SMS messages.
                </label>
                <div className="buttonDiv">
                    <button className="buttonBlack">
                        Sign Up
                    </button>
                </div>
            </div>
        </div>
        );
  }
 
export default SignUp;