
import React from 'react';
import './infoCards.css';
import { faStar } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import StaticData from '../staticData.json';
import SignUp from '../SignUp/signUp';
  
const InfoCards=()=> {

    return (
        <div className="infoCardMainDiv" >
            <div className="infoCardsRow">
                {StaticData && StaticData.infoCardData.map((data, index) =>(
                    <div className="infoCard">
                        <div className="cardHeadingDiv">
                            <label className="cardHeading">{data.cardName}</label>
                            {data.isNow ? 
                                <label className="adjective"> <FontAwesomeIcon icon={faStar}/> Now</label> 
                            : data.isPopular ? 
                                <label className="adjective"><FontAwesomeIcon icon={faStar}/> Popular</label> 
                            : null}
                        </div>
                        <div className="cardDetail">
                            {data.cardDetail}
                        </div>
                        <div className="yellowText">
                            {data.noOfUsers ? "NUMBER OF USERS" : "NUMBER OF PROVIDERS"}
                        </div>
                        <label>
                            {data.noOfUsers ? data.noOfUsers : data.noOfProviders}
                        </label>
                        <div className="yellowText">
                            <div>
                                {data.accuracy ? "ACCURACY" : data.setupTime ? "SET-UP TIME" : "TIME TO VISIT"}
                            </div>
                            <div>
                                COST
                            </div>
                        </div>
                        <div className="timeAndCost">
                            <label>
                                {data.accuracy ? <b>{data.accuracy}</b> : data.setupTime ? data.setupTime : data.timeToVisit}
                            </label>
                            <label>
                                {data.cost}
                            </label>
                        </div>
                        <div className="buttonDiv">
                            <button className={data.buttonText == "Get Yours" ? "buttonGreen" : "buttonBlack"}>
                                {data.buttonText}
                            </button>
                        </div>
                    </div>
                ))}
                <SignUp/>
            </div>
        </div>
        );
  }
 
export default InfoCards;