
import React from 'react';
import Header from '../Header/header';
import Searchbar from '../Searchbar/searchBar';
import AssociateCompanies from '../AssociateCompanies/associateCompanies';
import InfoCards from '../InfoCards/infoCards';
import Footer from '../Footer/footer';

const Home=()=> {  
      return (
        <React.Fragment>
            <Header/>
            <Searchbar/>
            <AssociateCompanies/>
            <InfoCards/>
            <Footer/>
        </React.Fragment>
        );
  }
 
export default Home;