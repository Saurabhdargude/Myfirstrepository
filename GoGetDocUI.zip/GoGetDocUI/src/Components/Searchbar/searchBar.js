import React from 'react';
import './searchbar.css';
import GoGetDoc from '../../Assets/gogetdoclogo.png';
import { faSearch } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import StaticData from '../staticData.json';
  
const SearchBar=()=> {

    return (
        <div className="searchBarMainDiv" >
            <img src={GoGetDoc} alt="Go Get Doc Logo" height="50"/>
            <div className="searchInputDiv">
                <input type="text" className="form-control" placeholder="Enter your Symptoms or Prescriptions..." aria-label="Search for Symptoms" aria-describedby="basic-addon1"/>
                <button className="searchButton"><FontAwesomeIcon icon={faSearch} /></button>
            </div>
            <div className="symptomsDiv">
                <label> Top Symptoms  </label>
                {StaticData && StaticData.topSymptoms.map((data, index) => (
                    <div className="symptomsBracket">
                        {data}
                    </div>
                )
                )}
            </div>
        </div>
        );
  }
 
export default SearchBar;