
import React from 'react';
import ABCLogo from '../../Assets/abclogo.png';
import PopularScienceLogo from '../../Assets/popSci.png';
import WasingtonPostLogo from '../../Assets/washingtonpost.png';
import CBSLogo from '../../Assets/cbslogo.png';
import USATodayLogo from '../../Assets/usatodaylogo.png';
import ForbesLogo from '../../Assets/forbes.png';
import CNBCLogo from '../../Assets/cnbclogo.png';
import WSJLogo from '../../Assets/wsjlogo.png';
  
const AssociateCompanies=()=> {

    return (
        <div className="associateCompaniesMainDiv" >
            <img src={ABCLogo} alt="ABC Logo" height="20" style={{margin:"0 1%"}} />
            <img src={PopularScienceLogo} alt="Popular Science Logo" height="20" style={{margin:"0 1%"}}/>
            <img src={WasingtonPostLogo} alt="The Washington Post Logo" height="20" style={{margin:"0 1%"}}/>
            <img src={CBSLogo} alt="CBS Logo" height="20" style={{margin:"0 1%"}}/>
            <img src={USATodayLogo} alt="USA Today Logo" height="20" style={{margin:"0 1%"}}/>
            <img src={ForbesLogo} alt="Forbes Logo" height="20" style={{margin:"0 1%"}}/>
            <img src={CNBCLogo} alt="CNBC Logo" height="20" style={{margin:"0 1%"}}/>
            <img src={WSJLogo} alt="WSJ Logo" height="20" style={{margin:"0 1%"}}/>
        </div>
        );
  }
 
export default AssociateCompanies;