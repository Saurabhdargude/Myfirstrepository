
import React from 'react';
import './header.css';
import StaticData from '../staticData.json';
  
const Header=()=> {

    return (
        <div className="headerMainDiv">
            <div className="headerLeftDiv"> <b>+{StaticData.noOfMembers}</b> members and growing </div>
            <div className="headerRightDiv">
                <button className="headerButton"> Get Doc </button>
                <button className="headerButton"> Sign In </button>
            </div>
        </div>
        );
  }
 
export default Header;