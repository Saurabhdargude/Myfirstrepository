import React from 'react';
import './footer.css';
import { faBookOpen, faCheckSquare, faCommentDollar, faNetworkWired, faStopCircle } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
  
const Footer=()=> {

    return (
            <div className="footer">
                <div className="footerContent">
                    <div className="footerLabelsUnderLined">
                        <FontAwesomeIcon icon={faStopCircle} />
                        <label>
                            &nbsp;VaxYes
                        </label>
                    </div>
                    <div className="footerLabels">
                        <FontAwesomeIcon icon={faCheckSquare} />
                        <label>
                            &nbsp;Get Tested
                        </label>
                    </div>
                    <div className="footerLabels">
                        <FontAwesomeIcon icon={faCommentDollar} />
                        <label>
                            &nbsp;WellPay
                        </label>
                    </div>
                    <div className="footerLabels">
                        <FontAwesomeIcon icon={faBookOpen} />
                        <label>
                            &nbsp;Our Story
                        </label>
                    </div>
                    <div className="footerLabels">
                        <FontAwesomeIcon icon={faNetworkWired} />
                        <label>
                            &nbsp;#memberOwned
                        </label>
                    </div>
                </div>
                <div className="footerContent">
                    <div className="footerLabels">
                        <label>
                            Need Help?
                        </label>
                    </div>
                    <div className="footerLabels">
                        <label>
                            Terms
                        </label>
                    </div>
                    <div className="footerLabels">
                        <label>
                            Privacy Policy
                        </label>
                    </div>
                </div>
            </div>
        );
  }
 
export default Footer;