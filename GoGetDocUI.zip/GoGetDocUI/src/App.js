import './App.css';
import Home from './Components/Home/home';

function App() {
  return (
    <div className="App">
        <Home/>
    </div>
  );
}

export default App;
